import os
import csv
from pathlib import Path

DATA_DIR = Path("data")
CONTRACTS_DIR = DATA_DIR / "contracts_txt"
CHECKLIST_FILE = DATA_DIR / "contract_checklist.csv"

REPORTS_DIR = Path("reports")
ISSUES_FILE = REPORTS_DIR / "contract_issues.csv"
SUMMARY_FILE = REPORTS_DIR / "contract_summary.txt"


def load_rules():
    rules = []
    with open(CHECKLIST_FILE, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rules.append(row)
    return rules


def load_contracts():
    contracts = {}
    for file in CONTRACTS_DIR.glob("*.txt"):
        with open(file, encoding="utf-8") as f:
            contracts[file.name] = f.read().lower()
    return contracts


def check_contracts(rules, contracts):
    results = []

    for contract_file, text in contracts.items():
        for rule in rules:
            pattern = rule["pattern"].lower()
            rule_type = rule["rule_type"]

            found = pattern in text

            if rule_type == "required":
                status = "FOUND" if found else "MISSING"
            else:
                status = "FOUND_RISK" if found else "NOT_FOUND"

            results.append({
                "contract_file": contract_file,
                "rule_id": rule["rule_id"],
                "rule_type": rule_type,
                "severity": rule["severity"],
                "pattern": rule["pattern"],
                "status": status,
                "comment": rule["comment"]
            })

    return results


def save_issues(results):
    REPORTS_DIR.mkdir(exist_ok=True)

    with open(ISSUES_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "contract_file",
                "rule_id",
                "rule_type",
                "severity",
                "pattern",
                "status",
                "comment"
            ]
        )
        writer.writeheader()
        writer.writerows(results)


def generate_summary(results):
    contracts = set(r["contract_file"] for r in results)

    critical = sum(
        1 for r in results
        if r["severity"] == "Критично"
        and r["status"] in ["MISSING", "FOUND_RISK"]
    )

    summary_lines = []
    summary_lines.append(f"Проверено договоров: {len(contracts)}")
    summary_lines.append(f"Критичных замечаний: {critical}")
    summary_lines.append("")

    for contract in contracts:
        summary_lines.append(f"Договор: {contract}")

        contract_results = [
            r for r in results if r["contract_file"] == contract
        ]

        issues = [
            r for r in contract_results
            if r["status"] in ["MISSING", "FOUND_RISK"]
        ]

        for r in issues[:5]:
            summary_lines.append(
                f"- {r['severity']} | {r['status']} | {r['pattern']}"
            )

        summary_lines.append("")

    with open(SUMMARY_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(summary_lines))


def main():
    print("Загрузка правил...")
    rules = load_rules()

    print("Загрузка договоров...")
    contracts = load_contracts()

    print("Проверка...")
    results = check_contracts(rules, contracts)

    print("Сохранение отчётов...")
    save_issues(results)
    generate_summary(results)

    print("Готово. Отчёты в папке reports/")


if __name__ == "__main__":
    main()
